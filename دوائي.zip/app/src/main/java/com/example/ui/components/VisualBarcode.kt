package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Random

@Composable
fun VisualBarcode(
    barcode: String,
    modifier: Modifier = Modifier,
    showText: Boolean = true
) {
    Column(
        modifier = modifier
            .background(Color.White, RoundedCornerShape(8.dp))
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
        ) {
            val width = size.width
            val numBars = 75
            val barWidth = width / numBars

            val hash = barcode.hashCode()
            val random = Random(hash.toLong())

            // Draw start sentinel
            for (i in 0..2) {
                if (i % 2 == 0) {
                    drawRect(
                        color = Color.Black,
                        topLeft = Offset(i * barWidth, 0f),
                        size = Size(barWidth, size.height)
                    )
                }
            }

            // Draw pseudo-random lines based on barcode value
            for (i in 3 until numBars - 3) {
                val isBlack = random.nextBoolean()
                if (isBlack) {
                    drawRect(
                        color = Color.Black,
                        topLeft = Offset(i * barWidth, 0f),
                        size = Size(barWidth, size.height)
                    )
                }
            }

            // Draw stop sentinel
            for (i in (numBars - 3) until numBars) {
                if ((numBars - i) % 2 != 0) {
                    drawRect(
                        color = Color.Black,
                        topLeft = Offset(i * barWidth, 0f),
                        size = Size(barWidth, size.height)
                    )
                }
            }
        }

        if (showText) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = barcode,
                color = Color.Black,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp
            )
        }
    }
}
