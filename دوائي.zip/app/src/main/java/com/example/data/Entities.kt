package com.example.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey val username: String,
    val passwordHash: String,
    val role: String, // "ADMIN", "EMPLOYEE"
    val canAddDrug: Boolean = true,
    val canEditDrug: Boolean = true,
    val canDeleteDrug: Boolean = true,
    val canDeleteSale: Boolean = true,
    val mustChangePassword: Boolean = false
)

@Entity(
    tableName = "drugs",
    indices = [Index(value = ["barcode"], unique = true)]
)
data class Drug(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val arabicName: String,
    val scientificName: String,
    val companyName: String,
    val categoryName: String,
    val strength: String,
    val dosageForm: String,
    val batchNumber: String,
    val productionDate: String,
    val expiryDate: String,
    val purchasePrice: Double, // in Iraqi Dinar (IQD)
    val salePrice: Double, // in Iraqi Dinar (IQD)
    val quantity: Int,
    val minLimit: Int,
    val barcode: String,
    val notes: String = "",
    val isArchived: Boolean = false
)

@Entity(
    tableName = "companies",
    indices = [Index(value = ["name"], unique = true)]
)
data class Company(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val details: String = ""
)

@Entity(
    tableName = "categories",
    indices = [Index(value = ["name"], unique = true)]
)
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String
)

@Entity(tableName = "sales_bills")
data class SaleBill(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val invoiceNumber: String,
    val timestamp: Long = System.currentTimeMillis(),
    val drugId: Int,
    val drugName: String,
    val quantity: Int,
    val unitPrice: Double,
    val totalPrice: Double,
    val username: String
)

@Entity(tableName = "operation_logs")
data class OperationLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val username: String,
    val timestamp: Long = System.currentTimeMillis(),
    val barcode: String,
    val drugName: String,
    val operationType: String, // "بيع", "شراء", "بحث", "إضافة", "تعديل", "حذف"
    val details: String
)

@Entity(tableName = "system_settings")
data class SystemSetting(
    @PrimaryKey val key: String,
    val value: String
)
